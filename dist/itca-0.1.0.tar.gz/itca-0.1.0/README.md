# ITCA - Guide the ambiguous outcome labels combination for multi-class classification
**ITCA**  (Information-theoretic classification accuracy) is a criterion that guides data-driven combination of ambiguous outcome labels in multi-class classification.

